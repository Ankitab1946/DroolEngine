"""Idempotent DQ/demo fact seeding; NEVER insert into existing PRJ reference masters."""
from decimal import Decimal
from sqlalchemy import select
from common.database import SessionLocal, init_db
from common.models import FinancialFact, Rule, Execution, Schedule, ImportBatch
from common.reference_data import attributes, portfolios
from common.schemas import RuleInput
from common.services import save_rule

def seed():
    init_db()
    with SessionLocal() as db:
        active_attrs = attributes(db, 'Y')
        active_ports = [p for p in portfolios(db) if p.is_active]
        if not active_attrs or not active_ports:
            # No artificial master records: the owner provisions these tables separately.
            return {'seeded': False, 'reason': 'Populate existing PRJ attribute and portfolio reference tables first.'}
        code = active_ports[0].short_code
        targets = [a.prj_id for a in active_attrs[:2]]
        if not db.scalar(select(FinancialFact.id).limit(1)):
            rows = [
                (targets[0], '2025-12', '8.4', 'PERCENT'),
                (targets[0], '2026-12', '5.8', 'PERCENT'),
            ]
            if len(targets)>1:
                rows += [(targets[1],'2025-12','100','MILLION'),(targets[1],'2026-12','170','MILLION')]
            db.add_all(FinancialFact(document_id='DEMO-001', company='DQ Sample Company', portfolio_code=code,
                  prj_id=p, period=period, value=Decimal(val), unit=unit, currency='INR')
                  for p,period,val,unit in rows)
            db.commit()
        if not db.get(Rule, 'Rule_06'):
            save_rule(db,RuleInput(id='Rule_06',name='Sample ratio not below 7%',rule_type='LIMIT',
                 targets=[targets[0]],portfolios=[code],status='ACTIVE',
                 config={'operator':'>=','threshold':'7','require_cde':True},severity='HIGH'))
        if len(targets)>1 and not db.get(Rule,'Rule_09'):
            save_rule(db,RuleInput(id='Rule_09',name='Sample movement above 50% flag',rule_type='MOVEMENT',
                 targets=[targets[1]],portfolios=[code],status='ACTIVE',
                 config={'operator':'>','threshold':'50','comparison_period':'PREVIOUS_YEAR','direction':'BOTH'},severity='HIGH'))
        # Populate DQ orchestration and results with one sample run, only on explicit opt-in.
        # Do not create fake email-delivery records or modify PRJ reference masters.
        if not db.get(Execution, 'DEMO-SEED-RUN'):
            db.add(Execution(id='DEMO-SEED-RUN', scope={'period':'2026-12','portfolio':code}))
            db.commit()
        if not db.scalar(select(Schedule.id).where(Schedule.name=='DQ sample monthly (disabled)')):
            db.add(Schedule(name='DQ sample monthly (disabled)',frequency='MONTHLY',
                hour_utc=1,minute_utc=0,day_of_month=1,rule_ids=['Rule_06','Rule_09'], active=False))
            db.commit()
        if not db.get(ImportBatch, 'DEMO-IMPORT'):
            db.add(ImportBatch(id='DEMO-IMPORT',filename='sample_rules.xlsx',candidates=[
                {'rule_id':'Rule_06','prj_id':targets[0],'status':'DRAFT_REVIEW',
                 'description':'Not below 7%'}]))
            db.commit()
    from common.execution import execute
    execute('DEMO-SEED-RUN')  # idempotent: only processes QUEUED runs
    return {'seeded': True, 'portfolio': code, 'target_prj_ids': targets}


if __name__=='__main__': print(seed())
