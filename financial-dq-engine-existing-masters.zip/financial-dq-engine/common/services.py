from sqlalchemy import select
from common.models import Rule, RuleVersion, RuleMapping
from common.schemas import RuleInput
from common.reference_data import get_attribute, get_portfolio

def version_for(db, rule):
    return db.scalar(select(RuleVersion).where(RuleVersion.rule_id==rule.id, RuleVersion.version==rule.current_version))

def validate_references(db, data: RuleInput):
    ids = set(data.targets)
    if data.config.get('other_prj_id'): ids.add(data.config['other_prj_id'])
    missing = {prj for prj in ids if get_attribute(db, prj) is None}
    if missing: raise ValueError(f'Unknown PRJ IDs: {sorted(missing)}')
    missing_ports = {code for code in data.portfolios if get_portfolio(db, code) is None}
    if missing_ports: raise ValueError(f'Unknown portfolios: {sorted(missing_ports)}')
    if data.status == 'ACTIVE' and data.config.get('require_cde', True):
        inactive = [prj for prj in ids if get_attribute(db, prj).is_cde != 'Y']
        if inactive: raise ValueError(f'Cannot activate rule: non-CDE attributes {inactive}')

def save_rule(db, data: RuleInput, update=False):
    validate_references(db, data)
    rule = db.get(Rule, data.id)
    if update and not rule: raise LookupError('Rule not found')
    if not update and rule: raise ValueError('Rule already exists')
    if rule:
        rule.current_version += 1
        rule.name, rule.rule_type, rule.severity, rule.status = data.name, data.rule_type, data.severity, data.status
        db.query(RuleMapping).filter(RuleMapping.rule_id==rule.id).delete()
    else:
        rule = Rule(id=data.id,name=data.name,rule_type=data.rule_type,status=data.status,severity=data.severity,current_version=1)
        db.add(rule)
    cfg = {**data.config, 'require_cde': data.config.get('require_cde', True)}
    db.add(RuleVersion(rule_id=data.id, version=rule.current_version,config=cfg,targets=data.targets,portfolios=data.portfolios))
    for target in sorted(set(data.targets)):
        db.add(RuleMapping(rule_id=data.id,prj_id=target,role='TARGET'))
    if data.config.get('other_prj_id'):
        db.add(RuleMapping(rule_id=data.id,prj_id=data.config['other_prj_id'],role='OPERAND'))
    db.commit()
    return rule

def serialize_rule(db, rule):
    v=version_for(db,rule)
    return {'id':rule.id,'name':rule.name,'rule_type':rule.rule_type,'status':rule.status,'severity':rule.severity,'version':rule.current_version,'targets':v.targets,'portfolios':v.portfolios,'config':v.config}
