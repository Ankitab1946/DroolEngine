import os, io, uuid, smtplib
from email.message import EmailMessage
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Header
from fastapi.responses import StreamingResponse
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from openpyxl import load_workbook
from common.database import SessionLocal,init_db
from common.models import FinancialFact,Rule,RuleVersion,RuleMapping,Execution,Schedule,ImportBatch,Notification,Result
from common.schemas import RuleInput,ExecutionInput,ScheduleInput,RULE_TYPES
from common.services import save_rule,serialize_rule,version_for,validate_references
from common.reporting import summary,excel_report
from common.execution import execute
from common.reference_data import attributes as source_attributes, get_attribute, portfolios as source_portfolios

@asynccontextmanager
async def lifespan(app):
    init_db()
    if os.getenv('SEED_DEMO','false').lower()=='true':
        from common.seed import seed
        seed()
    yield
app=FastAPI(title='Financial DQ Engine API',version='0.1.0',lifespan=lifespan)

def get_db():
    with SessionLocal() as db: yield db

def require_api_key(x_api_key: str|None=Header(None)):
    expected=os.getenv('DQ_API_KEY')
    if expected and x_api_key!=expected:raise HTTPException(401,'Invalid API key')

# Local development auth. Replace with SSO/OIDC + roles before enterprise use.
app.router.dependencies.append(Depends(require_api_key))

def fail(exc):
    if isinstance(exc,LookupError):raise HTTPException(404,str(exc))
    raise HTTPException(422,str(exc))

@app.get('/health')
def health():return {'status':'ok'}

@app.get('/api/v1/dq/rule-types')
def rule_types():return [{'id':x,'name':x.replace('_',' ').title()} for x in RULE_TYPES]

@app.get('/api/v1/dq/attributes')
def attributes(is_cde:str|None=None,db:Session=Depends(get_db)):
    return [vars(a) for a in source_attributes(db,is_cde.upper() if is_cde else None)]

@app.get('/api/v1/dq/attributes/{attribute_id}')
def attribute(attribute_id:str,db:Session=Depends(get_db)):
    a=get_attribute(db,attribute_id)
    if not a:raise HTTPException(404,'Attribute not found')
    return vars(a)

@app.get('/api/v1/dq/attributes/{attribute_id}/rules')
def attribute_rules(attribute_id:str,db:Session=Depends(get_db)):
    return [serialize_rule(db,r) for r in db.scalars(select(Rule).join(RuleMapping,Rule.id==RuleMapping.rule_id).where(RuleMapping.prj_id==attribute_id).distinct()).all()]

@app.get('/api/v1/dq/portfolios')
def portfolios(db:Session=Depends(get_db)):
    return [{'short_code':p.short_code,'name':p.portfolio_name,'sector':p.sector_name,'sub_sector':p.sub_sector,'is_active':p.is_active,'document_type_id':p.document_type_id} for p in source_portfolios(db)]

@app.get('/api/v1/dq/rules')
def rules(db:Session=Depends(get_db)):
    return [serialize_rule(db,r) for r in db.scalars(select(Rule).order_by(Rule.id)).all()]

@app.get('/api/v1/dq/rules/{rule_id}')
def rule_detail(rule_id:str,db:Session=Depends(get_db)):
    r=db.get(Rule,rule_id)
    if not r:raise HTTPException(404,'Rule not found')
    return serialize_rule(db,r)

@app.post('/api/v1/dq/rules',status_code=201)
def rule_create(payload:RuleInput,db:Session=Depends(get_db)):
    try:return serialize_rule(db,save_rule(db,payload))
    except (ValueError,LookupError) as e:fail(e)

@app.put('/api/v1/dq/rules/{rule_id}')
def rule_update(rule_id:str,payload:RuleInput,db:Session=Depends(get_db)):
    if payload.id!=rule_id:raise HTTPException(422,'ID cannot change')
    try:return serialize_rule(db,save_rule(db,payload,update=True))
    except (ValueError,LookupError) as e:fail(e)

@app.post('/api/v1/dq/rules/{rule_id}/validate')
def validate_rule(rule_id:str,db:Session=Depends(get_db)):
    r=db.get(Rule,rule_id)
    if not r:raise HTTPException(404,'Rule not found')
    v=version_for(db,r)
    try:
        validate_references(db,RuleInput(id=r.id,name=r.name,rule_type=r.rule_type,severity=r.severity,status='ACTIVE',targets=v.targets,portfolios=v.portfolios,config=v.config))
        return {'valid':True}
    except ValueError as e:return {'valid':False,'reason':str(e)}

@app.post('/api/v1/dq/rules/{rule_id}/activate')
def activate(rule_id:str,db:Session=Depends(get_db)):
    r=db.get(Rule,rule_id)
    if not r:raise HTTPException(404,'Rule not found')
    v=version_for(db,r)
    try:validate_references(db,RuleInput(id=r.id,name=r.name,rule_type=r.rule_type,severity=r.severity,status='ACTIVE',targets=v.targets,portfolios=v.portfolios,config=v.config))
    except ValueError as e:fail(e)
    r.status='ACTIVE';db.commit();return {'status':'ACTIVE'}

@app.post('/api/v1/dq/rules/{rule_id}/deactivate')
def deactivate(rule_id:str,db:Session=Depends(get_db)):
    r=db.get(Rule,rule_id)
    if not r:raise HTTPException(404,'Rule not found')
    r.status='INACTIVE';db.commit();return {'status':'INACTIVE'}

@app.get('/api/v1/dq/rules/{rule_id}/versions')
def versions(rule_id:str,db:Session=Depends(get_db)):
    return [{'version':v.version,'config':v.config,'targets':v.targets,'portfolios':v.portfolios} for v in db.scalars(select(RuleVersion).where(RuleVersion.rule_id==rule_id).order_by(RuleVersion.version)).all()]

@app.get('/api/v1/dq/rules/{rule_id}/attributes')
def mappings(rule_id:str,db:Session=Depends(get_db)):
    return [{'id':m.id,'prj_id':m.prj_id,'role':m.role,'collection_type':m.collection_type} for m in db.scalars(select(RuleMapping).where(RuleMapping.rule_id==rule_id)).all()]

@app.post('/api/v1/dq/executions',status_code=202)
def start(payload:ExecutionInput,idempotency_key:str|None=Header(None),db:Session=Depends(get_db)):
    if idempotency_key:
        existing=db.scalar(select(Execution).where(Execution.idempotency_key==idempotency_key))
        if existing:return {'execution_id':existing.id,'status':existing.status}
    eid=str(uuid.uuid4());run=Execution(id=eid,scope=payload.model_dump(),idempotency_key=idempotency_key)
    db.add(run);db.commit()
    if os.getenv('EXECUTION_MODE','sync')=='celery':
        from worker.tasks import run_validation
        run_validation.delay(eid)
    else:execute(eid)
    db.refresh(run)
    return {'execution_id':eid,'status':run.status}

@app.get('/api/v1/dq/executions')
def executions(db:Session=Depends(get_db)):
    return [{'id':x.id,'status':x.status,'scope':x.scope,'requested_at':x.requested_at.isoformat(),'error':x.error} for x in db.scalars(select(Execution).order_by(Execution.requested_at.desc()).limit(100)).all()]

@app.get('/api/v1/dq/executions/{execution_id}')
def execution_detail(execution_id:str,db:Session=Depends(get_db)):
    x=db.get(Execution,execution_id)
    if not x:raise HTTPException(404,'Execution not found')
    return {'id':x.id,'status':x.status,'scope':x.scope,'error':x.error,'requested_at':x.requested_at,'completed_at':x.completed_at}

@app.get('/api/v1/dq/executions/{execution_id}/results')
def results(execution_id:str,db:Session=Depends(get_db)):
    if not db.get(Execution,execution_id):raise HTTPException(404,'Execution not found')
    return summary(db,execution_id)

@app.post('/api/v1/dq/executions/{execution_id}/retry',status_code=202)
def retry(execution_id:str,db:Session=Depends(get_db)):
    x=db.get(Execution,execution_id)
    if not x:raise HTTPException(404,'Execution not found')
    if x.status!='FAILED':raise HTTPException(409,'Only failed jobs can be retried')
    return start(ExecutionInput(**{k:v for k,v in x.scope.items() if k in ExecutionInput.model_fields}),None,db)

@app.get('/api/v1/dq/schedules')
def schedules(db:Session=Depends(get_db)):
    return [{'id':s.id,'name':s.name,'frequency':s.frequency,'hour_utc':s.hour_utc,'minute_utc':s.minute_utc,'day_of_month':s.day_of_month,'rule_ids':s.rule_ids,'active':s.active} for s in db.scalars(select(Schedule)).all()]

@app.post('/api/v1/dq/schedules',status_code=201)
def create_schedule(data:ScheduleInput,db:Session=Depends(get_db)):
    s=Schedule(**data.model_dump());db.add(s);db.commit();db.refresh(s);return {'id':s.id}

@app.put('/api/v1/dq/schedules/{schedule_id}')
def update_schedule(schedule_id:int,data:ScheduleInput,db:Session=Depends(get_db)):
    s=db.get(Schedule,schedule_id)
    if not s:raise HTTPException(404,'Schedule not found')
    for k,v in data.model_dump().items():setattr(s,k,v)
    db.commit();return {'id':s.id}

@app.delete('/api/v1/dq/schedules/{schedule_id}')
def delete_schedule(schedule_id:int,db:Session=Depends(get_db)):
    s=db.get(Schedule,schedule_id)
    if not s:raise HTTPException(404,'Schedule not found')
    db.delete(s);db.commit();return {'deleted':True}

@app.post('/api/v1/dq/rules/import')
async def import_excel(file:UploadFile=File(...),db:Session=Depends(get_db)):
    blob=await file.read()
    if len(blob)>5_000_000:raise HTTPException(413,'Workbook too large')
    try:wb=load_workbook(io.BytesIO(blob),read_only=True,data_only=True)
    except Exception:raise HTTPException(422,'Invalid Excel workbook')
    sh=wb.active;rows=sh.iter_rows(values_only=True)
    try:header=[str(x or '').strip().lower() for x in next(rows)]
    except StopIteration:raise HTTPException(422,'Empty workbook')
    def col(*fragments):
        for i,h in enumerate(header):
            if all(f in h for f in fragments):return i
        return None
    rule_i=col('rule','id'); prj_i=col('prj','id'); desc_i=col('proposed','business','rule')
    if rule_i is None or prj_i is None:raise HTTPException(422,'Require Rule ID and PRJ ID columns; other Excel formats need mapping review')
    candidates=[]
    for row in rows:
        if not row or not row[rule_i] or not row[prj_i]:continue
        p=str(row[prj_i]).strip();a=get_attribute(db,p)
        candidates.append({'rule_id':str(row[rule_i]).strip(),'prj_id':p,'description':str(row[desc_i]) if desc_i is not None and row[desc_i] else '', 'valid_attribute':bool(a),'is_cde':a.is_cde if a else None,'status':'DRAFT_REVIEW'})
        if len(candidates)>=3000:break
    batch=ImportBatch(id=str(uuid.uuid4()),filename=file.filename or 'workbook.xlsx',candidates=candidates);db.add(batch);db.commit()
    return {'batch_id':batch.id,'rows':len(candidates),'candidates':candidates[:100], 'note':'Draft preview only; no rules activated. Configure rules in Rule Builder.'}

@app.get('/api/v1/dq/rules/import/{batch_id}')
def import_detail(batch_id:str,db:Session=Depends(get_db)):
    b=db.get(ImportBatch,batch_id)
    if not b:raise HTTPException(404,'Import not found')
    return {'batch_id':b.id,'filename':b.filename,'candidates':b.candidates}

@app.get('/api/v1/dq/reports/{execution_id}')
def report(execution_id:str,db:Session=Depends(get_db)):
    if not db.get(Execution,execution_id):raise HTTPException(404,'Execution not found')
    return summary(db,execution_id)

@app.get('/api/v1/dq/reports/{execution_id}/download')
def download(execution_id:str,db:Session=Depends(get_db)):
    if not db.get(Execution,execution_id):raise HTTPException(404,'Execution not found')
    return StreamingResponse(io.BytesIO(excel_report(db,execution_id)),media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',headers={'Content-Disposition':f'attachment; filename="dq_{execution_id}.xlsx"'})

@app.post('/api/v1/dq/reports/{execution_id}/email')
def email_report(execution_id:str,recipient:str,db:Session=Depends(get_db)):
    if not db.get(Execution,execution_id):raise HTTPException(404,'Execution not found')
    host=os.getenv('SMTP_HOST')
    if not host:raise HTTPException(503,'SMTP not configured')
    msg=EmailMessage();msg['From']=os.getenv('SMTP_FROM','dq@example.invalid');msg['To']=recipient;msg['Subject']='Financial DQ report'
    data=summary(db,execution_id);msg.set_content(f'DQ run {execution_id}\nTotal: {data["total"]}\nOutcomes: {data["outcomes"]}')
    msg.add_attachment(excel_report(db,execution_id),maintype='application',subtype='vnd.openxmlformats-officedocument.spreadsheetml.sheet',filename='DQ_Report.xlsx')
    try:
        with smtplib.SMTP(host,int(os.getenv('SMTP_PORT','587')),timeout=15) as conn:
            if os.getenv('SMTP_TLS','true')=='true':conn.starttls()
            if os.getenv('SMTP_USER'):conn.login(os.environ['SMTP_USER'],os.environ['SMTP_PASSWORD'])
            conn.send_message(msg)
        db.add(Notification(execution_id=execution_id,recipient=recipient,status='SENT'));db.commit()
    except Exception as e:
        db.add(Notification(execution_id=execution_id,recipient=recipient,status='FAILED',reason=type(e).__name__));db.commit()
        raise HTTPException(502,'Email delivery failed')
    return {'status':'SENT'}

@app.get('/api/v1/dq/dashboard')
def dashboard(db:Session=Depends(get_db)):
    return {'rules':db.scalar(select(func.count()).select_from(Rule)), 'active_rules':db.scalar(select(func.count()).select_from(Rule).where(Rule.status=='ACTIVE')),'executions':db.scalar(select(func.count()).select_from(Execution)),'violations':db.scalar(select(func.count()).select_from(Result).where(Result.outcome=='FAIL'))}
