"""Regression tests: existing masters are read-only; startup does not issue DDL."""
import pytest
from sqlalchemy import create_engine, text, inspect, event
from common.database import Base, check_schema_compatibility
from common import models  # noqa: F401


def make_existing_reference_tables(conn):
    # TEST FIXTURES ONLY. Production reference masters are never created by app.
    conn.execute(text('CREATE TABLE prj_attribute_master (prj_id TEXT PRIMARY KEY, attribute_name TEXT, is_cde TEXT, cfi_id TEXT)'))
    conn.execute(text('CREATE TABLE prj_portfolio_reference (short_code TEXT PRIMARY KEY, portfolio_name TEXT, is_active TEXT, sector_name TEXT)'))


def test_old_schema_rejected_without_modification():
    engine = create_engine('sqlite://')
    with engine.begin() as connection:
        make_existing_reference_tables(connection)
        connection.execute(text('ALTER TABLE prj_attribute_master RENAME COLUMN is_cde TO legacy_cde'))
        connection.execute(text("INSERT INTO prj_attribute_master(prj_id, legacy_cde) VALUES ('KEEP_ME','Y')"))
        with pytest.raises(RuntimeError, match='Missing columns') as exc:
            check_schema_compatibility(connection)
        assert 'is_cde' in str(exc.value)
        assert connection.scalar(text('SELECT prj_id FROM prj_attribute_master')) == 'KEEP_ME'


def test_missing_tables_rejected_without_creating_them():
    engine = create_engine('sqlite://')
    statements = []
    @event.listens_for(engine, 'before_cursor_execute')
    def track(conn, cursor, statement, parameters, context, executemany):
        statements.append(statement)
    with engine.connect() as connection:
        with pytest.raises(RuntimeError, match='Missing tables'):
            check_schema_compatibility(connection)
        assert inspect(connection).get_table_names() == []
    assert not any('CREATE ' in s.upper() or 'DROP ' in s.upper() for s in statements)


def test_manually_created_schema_is_accepted():
    engine = create_engine('sqlite://')
    with engine.begin() as connection:
        Base.metadata.create_all(connection)  # simulate DBA provisioning in a test
        make_existing_reference_tables(connection)
        check_schema_compatibility(connection)
        assert 'prj_id' in {c['name'] for c in inspect(connection).get_columns('prj_attribute_master')}


def test_init_db_does_not_issue_ddl(monkeypatch):
    from common import database
    engine = create_engine('sqlite://')
    with engine.begin() as conn:
        Base.metadata.create_all(conn)
        make_existing_reference_tables(conn)
    emitted = []
    @event.listens_for(engine, 'before_cursor_execute')
    def track(conn, cursor, statement, parameters, context, executemany):
        emitted.append(statement.upper())
    monkeypatch.setattr(database, 'engine', engine)
    database.init_db()
    assert not any('CREATE ' in x or 'ALTER ' in x or 'DROP ' in x for x in emitted)
