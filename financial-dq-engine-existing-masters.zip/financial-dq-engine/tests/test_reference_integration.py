"""End-to-end test using read-only existing-table stand-ins in a disposable SQLite DB."""
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from common.database import Base
from common import database, reference_data, seed, execution
from common.models import Rule, FinancialFact, Execution
from common.schemas import ExecutionInput
from common.services import validate_references
from common.schemas import RuleInput


def test_real_masters_used_without_modification(tmp_path,monkeypatch):
    engine = create_engine(f'sqlite:///{tmp_path / "test.db"}')
    with engine.begin() as con:
        # Only tests may provision fake reference masters; app never does this.
        con.execute(text('CREATE TABLE prj_attribute_master (prj_id TEXT PRIMARY KEY, attribute_name TEXT, is_cde TEXT, cfi_id TEXT)'))
        con.execute(text('CREATE TABLE prj_portfolio_reference (short_code TEXT PRIMARY KEY, portfolio_name TEXT, is_active TEXT, sector_name TEXT)'))
        con.execute(text("INSERT INTO prj_attribute_master VALUES ('PRJ105','Ratio','Y',NULL),('PRJ124','Revenue','Y',NULL)"))
        con.execute(text("INSERT INTO prj_portfolio_reference VALUES ('BANK','Banking','Y','Finance')"))
        Base.metadata.create_all(con)
    sessions = sessionmaker(engine, expire_on_commit=False)
    monkeypatch.setattr(database,'engine',engine)
    monkeypatch.setattr(reference_data,'engine',engine)
    monkeypatch.setattr(seed,'SessionLocal',sessions)
    monkeypatch.setattr(execution,'SessionLocal',sessions)
    reference_data.reference_table.cache_clear()
    try:
        result=seed.seed()
        assert result['seeded']
        result2=seed.seed()
        assert result2['seeded']
        with sessions() as db:
            assert len(db.query(FinancialFact).all())==4
            assert len(db.query(Rule).all())==2
            # New CDE classification immediately blocks activation.
            with engine.begin() as con:
                con.execute(text("UPDATE prj_attribute_master SET is_cde='N' WHERE prj_id='PRJ105'"))
            from common.reference_data import get_attribute
            assert get_attribute(db,'PRJ105').is_cde=='N'
            from common.services import validate_references
            import pytest
            with pytest.raises(ValueError,match='non-CDE'):
                validate_references(db,RuleInput(id='XX',name='Check',rule_type='LIMIT',targets=['PRJ105'],portfolios=['BANK'],status='ACTIVE',config={'operator':'>=','threshold':'7'}))
            run=Execution(id='sample-run',scope={'period':'2026-12','portfolio':'BANK'})
            db.add(run);db.commit()
        execution.execute('sample-run')
        with sessions() as db:
            assert db.get(Execution,'sample-run').status=='COMPLETED'
            assert db.execute(text("SELECT count(*) FROM dq_validation_results WHERE outcome='SKIPPED'")).scalar()>=1
            assert db.execute(text("SELECT count(*) FROM dq_validation_results WHERE outcome='FAIL'")).scalar()>=1
        with engine.connect() as con:
            assert con.execute(text('SELECT count(*) FROM prj_attribute_master')).scalar()==2
            assert con.execute(text('SELECT count(*) FROM prj_portfolio_reference')).scalar()==1
    finally:
        reference_data.reference_table.cache_clear()
