"""Swagger contracts and idempotent demo seeding against disposable test tables."""
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from common.database import Base, check_schema_compatibility
from common import database, reference_data, seed, execution
from common.models import FinancialFact, Rule, Result, Execution
from api import main


def test_swagger_lists_all_dq_endpoints(monkeypatch):
    monkeypatch.setenv('DQ_API_KEY', 'sample-key')
    client = TestClient(main.app)
    assert client.get('/docs').status_code == 200
    response = client.get('/openapi.json')
    assert response.status_code == 200
    schema = response.json()
    required = {
        '/api/v1/dq/rules', '/api/v1/dq/rule-types',
        '/api/v1/dq/attributes', '/api/v1/dq/portfolios',
        '/api/v1/dq/executions', '/api/v1/dq/dashboard',
        '/api/v1/dq/demo/seed', '/api/v1/dq/demo/status',
    }
    assert required <= set(schema['paths'])
    assert len(schema['paths']) >= 25
    assert schema['components']['securitySchemes']['APIKeyHeader']['name'] == 'X-API-Key'
    assert client.get('/api/v1/dq/rules').status_code == 401


def test_demo_seed_and_reporting_via_http(tmp_path, monkeypatch):
    engine = create_engine(f'sqlite:///{tmp_path / "api.db"}', connect_args={'check_same_thread': False})
    with engine.begin() as connection:
        connection.execute(text('CREATE TABLE prj_attribute_master (prj_id TEXT PRIMARY KEY, attribute_name TEXT, is_cde TEXT, cfi_id TEXT)'))
        connection.execute(text('CREATE TABLE prj_portfolio_reference (short_code TEXT PRIMARY KEY, portfolio_name TEXT, is_active TEXT, sector_name TEXT)'))
        connection.execute(text("INSERT INTO prj_attribute_master VALUES ('PRJ105', 'Capital Ratio', 'Y', NULL), ('PRJ124', 'Revenue', 'Y', NULL)"))
        connection.execute(text("INSERT INTO prj_portfolio_reference VALUES ('BANK', 'Banking', 'Y', 'Financials')"))
        Base.metadata.create_all(connection)  # TEST ONLY: simulates manual DBA provisioning
        check_schema_compatibility(connection)
    sessions = sessionmaker(engine, expire_on_commit=False)
    monkeypatch.setattr(database, 'engine', engine)
    monkeypatch.setattr(reference_data, 'engine', engine)
    monkeypatch.setattr(main, 'SessionLocal', sessions)
    monkeypatch.setattr(seed, 'SessionLocal', sessions)
    monkeypatch.setattr(execution, 'SessionLocal', sessions)
    monkeypatch.setenv('SEED_DEMO', 'true')
    monkeypatch.setenv('DQ_API_KEY', 'sample-key')
    monkeypatch.setenv('EXECUTION_MODE', 'sync')
    reference_data.reference_table.cache_clear()
    try:
        client = TestClient(main.app)
        headers = {'X-API-Key': 'sample-key'}
        seeded = client.post('/api/v1/dq/demo/seed', headers=headers)
        assert seeded.status_code == 200, seeded.text
        assert seeded.json()['seeded']
        assert client.post('/api/v1/dq/demo/seed', headers=headers).status_code == 200
        status = client.get('/api/v1/dq/demo/status', headers=headers)
        assert status.status_code == 200
        assert status.json()['demo_fact_count'] == 4
        rules = client.get('/api/v1/dq/rules', headers=headers).json()
        assert {r['id'] for r in rules} >= {'Rule_06', 'Rule_09'}
        reports = client.get('/api/v1/dq/executions/DEMO-SEED-RUN/results', headers=headers).json()
        assert reports['outcomes'].get('FAIL', 0) == 2
        excel = client.get('/api/v1/dq/reports/DEMO-SEED-RUN/download', headers=headers)
        assert excel.status_code == 200
        assert excel.content[:2] == b'PK'
        with sessions() as db:
            assert db.query(FinancialFact).count() == 4
            assert db.query(Rule).count() == 2
            assert db.query(Execution).count() == 1
            assert db.query(Result).count() >= 2
            assert db.execute(text('SELECT count(*) FROM prj_attribute_master')).scalar() == 2
    finally:
        reference_data.reference_table.cache_clear()


def test_demo_seed_disabled(monkeypatch):
    monkeypatch.setenv('SEED_DEMO', 'false')
    monkeypatch.setenv('DQ_API_KEY', 'sample-key')
    r = TestClient(main.app).post('/api/v1/dq/demo/seed', headers={'X-API-Key': 'sample-key'})
    assert r.status_code == 403
