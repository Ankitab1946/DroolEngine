"""Shared session factory and read-only schema verification.

Database objects are provisioned exclusively by DBA-executed SQL.
Startup never creates or modifies schemas, tables, or indexes.
"""
from sqlalchemy import create_engine, inspect
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from common.config import database_connection, postgres_enabled, postgres_schema

DATABASE_URL, connect_args = database_connection()
engine = create_engine(DATABASE_URL, pool_pre_ping=True, connect_args=connect_args)
SessionLocal = sessionmaker(engine, expire_on_commit=False)

class Base(DeclarativeBase):
    pass


def check_schema_compatibility(connection):
    """Report missing mapped columns, never silently change existing tables."""
    inspector = inspect(connection)
    incompatible = []
    missing_tables = []
    for table in Base.metadata.sorted_tables:
        if not inspector.has_table(table.name, schema=table.schema):
            missing_tables.append(table.name)
            continue
        actual = {column['name'] for column in inspector.get_columns(table.name, schema=table.schema)}
        missing = sorted(set(table.columns.keys()) - actual)
        if missing:
            incompatible.append((table.name, missing))
    if missing_tables or incompatible:
        details = '; '.join(f'{name}: missing {", ".join(columns)}' for name, columns in incompatible)
        raise RuntimeError(
            'Required DQ tables are missing or incompatible. '
            + ('Missing tables: ' + ', '.join(sorted(missing_tables)) + '. ' if missing_tables else '')
            + ('Missing columns: ' + details + '. ' if incompatible else '')
            + 'Application startup will not create or alter database objects. '
            + 'Ask your DBA to run sql/postgres_create_tables.sql in the existing PG_SCHEMA '
            + '(or provide pre-created tables in your local SQLite database). '
            + 'No data was modified.'
        )


def init_db():
    """Verify existing tables only; never issue DDL or CREATE SCHEMA."""
    from common import models  # noqa: F401
    with engine.connect() as conn:
        check_schema_compatibility(conn)


def session_scope():
    return SessionLocal()
