"""Regression tests for manual DDL provisioning and non-destructive startup."""
import pytest
from sqlalchemy import create_engine, text, inspect, event
from common.database import Base, check_schema_compatibility
from common import models  # noqa: F401


def test_old_schema_rejected_without_modification():
    engine = create_engine('sqlite://')
    with engine.begin() as connection:
        connection.execute(text('CREATE TABLE demo_cfv_attribute_masters (legacy_key TEXT PRIMARY KEY)'))
        connection.execute(text("INSERT INTO demo_cfv_attribute_masters VALUES ('KEEP_ME')"))
        with pytest.raises(RuntimeError, match='Missing columns') as exc:
            check_schema_compatibility(connection)
        assert 'prj_id' in str(exc.value)
        assert connection.scalar(text('SELECT legacy_key FROM demo_cfv_attribute_masters')) == 'KEEP_ME'


def test_missing_tables_rejected_without_creating_them():
    engine = create_engine('sqlite://')
    statements = []
    @event.listens_for(engine, 'before_cursor_execute')
    def track(conn, cursor, statement, parameters, context, executemany):
        statements.append(statement)
    with engine.connect() as connection:
        with pytest.raises(RuntimeError, match='Missing tables'):
            check_schema_compatibility(connection)
        assert inspect(connection).get_table_names() == []
    assert not any('CREATE ' in s.upper() or 'DROP ' in s.upper() for s in statements)


def test_manually_created_schema_is_accepted():
    engine = create_engine('sqlite://')
    with engine.begin() as connection:
        Base.metadata.create_all(connection)  # simulate a DBA having provisioned tables
        check_schema_compatibility(connection)
        cols = {c['name'] for c in inspect(connection).get_columns('demo_cfv_attribute_masters')}
        assert 'prj_id' in cols


def test_init_db_does_not_issue_ddl(monkeypatch):
    from common import database
    engine = create_engine('sqlite://')
    with engine.begin() as conn:
        Base.metadata.create_all(conn)  # DBA provisioning fixture
    emitted = []
    @event.listens_for(engine, 'before_cursor_execute')
    def track(conn, cursor, statement, parameters, context, executemany):
        emitted.append(statement.upper())
    monkeypatch.setattr(database, 'engine', engine)
    database.init_db()
    assert not any('CREATE ' in x or 'ALTER ' in x or 'DROP ' in x for x in emitted)
