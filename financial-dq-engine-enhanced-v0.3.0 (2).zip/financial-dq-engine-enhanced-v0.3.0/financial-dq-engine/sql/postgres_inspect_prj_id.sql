-- READ-ONLY DIAGNOSTIC. Replace dq_app with your existing PG_SCHEMA.
-- Confirm the schema and actual spelling of the ID columns before any migration.
SELECT table_schema, table_name, column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_schema = 'dq_app'
  AND table_name IN (
    'demo_normalized_financial_facts',
    'dq_rule_cde_mapping',
    'dq_validation_results'
  )
ORDER BY table_name, ordinal_position;

-- Confirm whether a legacy column named pri_id is populated (run only if above shows pri_id):
-- SELECT pri_id FROM dq_app.demo_normalized_financial_facts LIMIT 5;
-- SELECT pri_id FROM dq_app.dq_rule_cde_mapping LIMIT 5;
-- SELECT pri_id FROM dq_app.dq_validation_results LIMIT 5;
