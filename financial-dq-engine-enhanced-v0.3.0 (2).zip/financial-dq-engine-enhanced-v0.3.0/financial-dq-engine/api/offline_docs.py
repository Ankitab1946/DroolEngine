"""Dependency-free interactive documentation for networks blocking Swagger CDN.

Consumes the exact FastAPI /openapi.json specification: routes are never duplicated
or manually maintained. The official Swagger UI remains at /swagger-cdn.
"""
from html import escape


def render_docs() -> str:
    return '''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Financial DQ Engine — API Documentation</title>
<style>
:root{font-family:system-ui,-apple-system,Segoe UI,sans-serif;color:#252a31;background:#fafafa}
*{box-sizing:border-box}body{margin:0}.mast{background:#17314b;color:white;padding:19px 5%}
h1{font-size:23px;margin:0 0 5px} .mast p{margin:0;color:#c9d8e9;font-size:13px}
main{max-width:1200px;margin:auto;padding:22px 24px}.toolbar{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin:12px 0 28px}
input,textarea,button{font:inherit}input,textarea{padding:9px;border:1px solid #bdc4cc;border-radius:4px;max-width:100%}input{min-width:230px}button{cursor:pointer;background:#fff;color:#303740;border:1px solid #a6b0bc;border-radius:4px;padding:9px 12px}
button.primary{background:#2077bd;color:white;border-color:#2077bd}.hint{font-size:13px;color:#596574}.tag{font-size:21px;font-weight:650;border-bottom:1px solid #ddd;padding:17px 0 10px;margin:10px 0}
.endpoint{border:1px solid;border-radius:5px;margin:9px 0;overflow:hidden}.summary{width:100%;border:0;text-align:left;padding:9px 12px;display:flex;align-items:center;gap:14px;background:transparent}
.method{font-size:13px;font-weight:700;color:white;border-radius:3px;min-width:79px;text-align:center;padding:7px 5px}.path{font-family:ui-monospace,Consolas,monospace;font-weight:600;font-size:14px}.desc{font-size:12px;color:#526170}
.endpoint[data-method=GET]{background:#eaf4fc;border-color:#83b8e2}.endpoint[data-method=GET] .method{background:#2479bb}
.endpoint[data-method=POST]{background:#e9f6ed;border-color:#7fc497}.endpoint[data-method=POST] .method{background:#339a57}
.endpoint[data-method=PUT]{background:#fff4e5;border-color:#e2b567}.endpoint[data-method=PUT] .method{background:#d08e19}
.endpoint[data-method=DELETE]{background:#fcecec;border-color:#e19b9b}.endpoint[data-method=DELETE] .method{background:#c74b4b}
.endpoint[data-method=PATCH]{background:#eff0fd;border-color:#a6a6e8}.endpoint[data-method=PATCH] .method{background:#7373c2}
.detail{padding:16px 19px;background:white;border-top:1px solid #ced8e2}.detail h4{margin:15px 0 7px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#263342;color:#f2f6fa;padding:15px;border-radius:5px;font-size:12px;max-height:420px;overflow:auto}
textarea{width:100%;min-height:110px;font-family:ui-monospace,monospace} .params{display:grid;grid-template-columns:120px 1fr;gap:9px;align-items:center}.params label{font-size:13px}
.small{font-size:12px}a{color:#1567a1}@media(max-width:600px){.summary{gap:5px;flex-wrap:wrap}.method{min-width:55px}.params{grid-template-columns:1fr}}
</style></head><body>
<header class="mast"><h1>Financial DQ Engine API</h1><p>Interactive, offline API documentation · OpenAPI 3 · /openapi.json</p></header>
<main><div class="toolbar"><label>API key <input type="password" id="key" placeholder="X-API-Key from .env" autocomplete="off"></label>
<button onclick="loadRoutes()">Refresh endpoints</button><a href="/openapi.json">OpenAPI JSON</a><a href="/swagger-cdn">Official Swagger UI (needs internet/CDN)</a></div>
<p class="hint">Select an endpoint to expand its parameters and send a test request. Endpoints are loaded directly from the application's OpenAPI specification; no external scripts or stylesheets are required.</p>
<div id="status" role="status">Loading API routes…</div><div id="routes"></div></main>
<script>
const root=document.getElementById('routes'),status=document.getElementById('status');
const el=(tag,cls,text)=>{let x=document.createElement(tag);if(cls)x.className=cls;if(text!==undefined)x.textContent=text;return x;};
function makeRow(method,path,op,schemas){
 const box=el('section','endpoint');box.dataset.method=method;const summary=el('button','summary');summary.type='button';
 summary.append(el('span','method',method),el('span','path',path),el('span','desc',op.summary||op.operationId||''));box.append(summary);
 const detail=el('div','detail');detail.hidden=true;summary.onclick=()=>{detail.hidden=!detail.hidden};
 const desc=el('p','hint',op.description||op.summary||'');detail.append(desc);
 const params=el('div','params');const inputs=[];
 for(const p of (op.parameters||[])){
   const label=el('label','',p.name+(p.required?' *':''));const input=el('input');input.placeholder=p.in+' · '+(p.schema?.type||'string');
   params.append(label,input);inputs.push({p,input});
 }
 if(inputs.length){detail.append(el('h4','', 'Parameters'),params)}
 let body=null;
 if(op.requestBody){detail.append(el('h4','', 'Request body (JSON)'));body=el('textarea');
   let schema=op.requestBody.content?.['application/json']?.schema;
   if(schema?.$ref){schema=schemas[schema.$ref.split('/').pop()]||schema}
   const sample={};for(const [name,prop] of Object.entries(schema?.properties||{})){
      if(prop.default!==undefined)sample[name]=prop.default;
      else if(prop.type==='array')sample[name]=[];
      else if(prop.type==='object')sample[name]={};
      else if(prop.type==='integer'||prop.type==='number')sample[name]=0;
      else if(prop.type==='boolean')sample[name]=false;
      else sample[name]='';
   }
   body.value=JSON.stringify(sample,null,2);detail.append(body);
 }
 const run=el('button','primary','Try it out / Execute'),response=el('pre');response.hidden=true;
 run.onclick=async()=>{
   let url=path,query=new URLSearchParams();
   for(const {p,input} of inputs){const val=input.value.trim();if(!val){if(p.required){response.hidden=false;response.textContent='Required: '+p.name;return;}continue;}
     if(p.in==='path')url=url.replace('{'+p.name+'}',encodeURIComponent(val));
     if(p.in==='query')query.append(p.name,val);
   }
   if(query.toString())url+='?'+query.toString();
   const headers={};const key=document.getElementById('key').value.trim();if(key)headers['X-API-Key']=key;
   const opts={method,headers};if(body){opts.headers['Content-Type']='application/json';opts.body=body.value}
   response.hidden=false;response.textContent='Sending '+method+' '+url+'…';
   try{const res=await fetch(url,opts);const content=await res.text();
    try{response.textContent=res.status+' '+res.statusText+'\\n'+JSON.stringify(JSON.parse(content),null,2)}
    catch{response.textContent=res.status+' '+res.statusText+'\\n'+content.slice(0,20000)}
   }catch(e){response.textContent='Request error: '+e.message}
 };
 detail.append(run,response);box.append(detail);return box;
}
async function loadRoutes(){root.replaceChildren();status.textContent='Loading API routes…';
 try{const response=await fetch('/openapi.json',{cache:'no-store'});
 if(!response.ok)throw new Error('HTTP '+response.status);
 const spec=await response.json(),grouped=new Map();let count=0;
 for(const [path,methods] of Object.entries(spec.paths||{}))for(const [method,op] of Object.entries(methods)){
   if(!['get','post','put','patch','delete'].includes(method.toLowerCase()))continue;
   const group=(op.tags&&op.tags[0])||'Other';if(!grouped.has(group))grouped.set(group,[]);
   grouped.get(group).push([method.toUpperCase(),path,op]);count++;
 }
 for(const [group,routes] of grouped){root.append(el('h2','tag',group));
   for(const [method,path,op] of routes)root.append(makeRow(method,path,op,spec.components?.schemas||{}));
 }
 status.textContent=count+' endpoints loaded across '+grouped.size+' groups.';
 }catch(e){status.textContent='Cannot load /openapi.json: '+e.message+'; verify FastAPI is running at the correct port.'}
}
loadRoutes();
</script></body></html>'''
