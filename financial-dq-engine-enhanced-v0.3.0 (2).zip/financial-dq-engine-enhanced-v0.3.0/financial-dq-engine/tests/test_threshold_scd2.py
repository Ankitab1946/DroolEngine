"""Regression coverage for configurable thresholds and SCD2 audit."""
from decimal import Decimal
from types import SimpleNamespace
from sqlalchemy import create_engine, text, select
from sqlalchemy.orm import sessionmaker
from fastapi.testclient import TestClient
from common import reference_data
from common.database import Base, check_schema_compatibility
from common.models import Rule, RuleVersion
from common.schemas import RuleInput
from common.services import save_rule, change_rule_status, serialize_history
from common.execution import evaluate
from api.main import app


def test_threshold_normalization_and_validation():
    r = RuleInput(id='LIMIT_PCT',name='Ratio at least 1.1 percent',rule_type='LIMIT',
                  targets=['PRJ105'], config={'operator':'>=','threshold_value':'1.1','threshold_type':'PERCENTAGE'})
    assert r.config['threshold'] == '1.1'
    assert r.threshold_value == Decimal('1.1')
    fact=SimpleNamespace(value=Decimal('1.0'),unit='PERCENT')
    assert evaluate('LIMIT',[],fact,r.config,{})[0] is False
    fact.value=Decimal('1.2')
    assert evaluate('LIMIT',[],fact,r.config,{})[0] is True
    fact.value=Decimal('0.012');fact.unit='FRACTION'
    assert evaluate('LIMIT',[],fact,r.config,{})[0] is True
    count_rule=RuleInput(id='DUP_COUNT',name='Duplicate count',rule_type='DUPLICATE',targets=['PRJ105'],config={})
    assert count_rule.config['threshold_value']=='1'
    assert count_rule.config['threshold_type']=='COUNT'


def test_scd2_threshold_and_status_history(tmp_path,monkeypatch):
    engine=create_engine(f'sqlite:///{tmp_path / "scd2.sqlite"}')
    with engine.begin() as c:
        c.execute(text('CREATE TABLE prj_attribute_master (prj_id TEXT PRIMARY KEY, attribute_name TEXT, is_cde TEXT)'))
        c.execute(text('CREATE TABLE prj_portfolio_reference (short_code TEXT PRIMARY KEY, portfolio_name TEXT, is_active TEXT)'))
        c.execute(text("INSERT INTO prj_attribute_master VALUES ('PRJ105','Ratio','Y')"))
        c.execute(text("INSERT INTO prj_portfolio_reference VALUES ('BANK','Banks','Y')"))
        Base.metadata.create_all(c)  # test fixture only
        check_schema_compatibility(c)
    sessions=sessionmaker(engine,expire_on_commit=False)
    monkeypatch.setattr(reference_data, "engine", engine)
    reference_data.reference_table.cache_clear()
    try:
        with sessions() as db:
            r=save_rule(db,RuleInput(id='Rule_A',name='Minimum ratio',rule_type='LIMIT',
                targets=['PRJ105'],portfolios=['BANK'],status='DRAFT',changed_by='alice',
                config={'operator':'>=','threshold_value':'1.1','threshold_type':'PERCENTAGE'}))
            assert r.current_version==1
            r=save_rule(db,RuleInput(id='Rule_A',name='Minimum ratio',rule_type='LIMIT',
                targets=['PRJ105'],portfolios=['BANK'],status='DRAFT',changed_by='bob',change_reason='Adjusted limit',
                config={'operator':'>=','threshold_value':'1.0','threshold_type':'PERCENTAGE'}),update=True)
            assert r.current_version==2
            change_rule_status(db,r,'ACTIVE',changed_by='reviewer')
            assert r.current_version==3
            change_rule_status(db,r,'ACTIVE')
            assert r.current_version==3
            change_rule_status(db,r,'INACTIVE',changed_by='reviewer')
            assert r.current_version==4
            history=db.scalars(select(RuleVersion).where(RuleVersion.rule_id=='Rule_A').order_by(RuleVersion.version)).all()
            assert len(history)==4
            assert [h.status_snapshot for h in history]==['DRAFT','DRAFT','ACTIVE','INACTIVE']
            assert [str(h.threshold_value) for h in history] == ['1.10000000','1.00000000','1.00000000','1.00000000']
            assert sum(h.is_current for h in history)==1
            assert all(h.effective_to is not None for h in history[:-1])
            assert history[-1].effective_to is None
            assert history[1].changed_by=='bob'
            assert serialize_history(history[1])['change_reason']=='Adjusted limit'
    finally:
        reference_data.reference_table.cache_clear()


def test_openapi_and_cdn_free_route_catalogue(monkeypatch):
    monkeypatch.setenv("DQ_API_KEY", "sample-key")
    c=TestClient(app)
    schema=c.get('/openapi.json').json()
    assert '/api/v1/dq/rules/{rule_id}/audit' in schema['paths']
    assert '/api/v1/dq/system/routes' in schema['paths']
    assert 'threshold_value' in schema['components']['schemas']['RuleInput']['properties']
    catalogue=c.get('/api-reference')
    assert catalogue.status_code==200
    assert 'http://localhost:8000/docs' in catalogue.text
    assert '/api/v1/dq/rules' in catalogue.text
    assert c.get('/api/v1/dq/system/routes',headers={'X-API-Key':'sample-key'}).json()['total_paths'] >= 25
