"""Regression: PostgreSQL BOOLEAN is_cde must not be compared to VARCHAR 'Y'."""
from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session
from common import reference_data


def test_boolean_cde_filter_and_labels(tmp_path, monkeypatch):
    engine = create_engine(f'sqlite:///{tmp_path / "boolean.db"}')
    with engine.begin() as connection:
        connection.execute(text('CREATE TABLE prj_attribute_master (prj_id TEXT PRIMARY KEY, attribute_name TEXT, is_cde BOOLEAN NOT NULL)'))
        connection.execute(text("INSERT INTO prj_attribute_master VALUES ('PRJ105', 'Ratio', 1), ('PRJ124', 'Revenue', 0)"))
    monkeypatch.setattr(reference_data, 'engine', engine)
    reference_data.reference_table.cache_clear()
    try:
        with Session(engine) as db:
            all_rows = reference_data.attributes(db)
            assert {(a.prj_id, a.is_cde) for a in all_rows} == {('PRJ105','Y'), ('PRJ124','N')}
            assert [a.prj_id for a in reference_data.attributes(db, is_cde='Y')] == ['PRJ105']
            assert [a.prj_id for a in reference_data.attributes(db, is_cde='N')] == ['PRJ124']
            assert reference_data.get_attribute(db, 'PRJ105').is_cde == 'Y'
            assert reference_data.get_attribute(db, 'PRJ124').is_cde == 'N'
    finally:
        reference_data.reference_table.cache_clear()


def test_text_cde_backward_compatible(tmp_path, monkeypatch):
    engine = create_engine(f'sqlite:///{tmp_path / "text.db"}')
    with engine.begin() as connection:
        connection.execute(text('CREATE TABLE prj_attribute_master (prj_id TEXT PRIMARY KEY, attribute_name TEXT, is_cde VARCHAR(1) NOT NULL)'))
        connection.execute(text("INSERT INTO prj_attribute_master VALUES ('PRJ105', 'Ratio', 'Y'), ('PRJ124', 'Revenue', 'N')"))
    monkeypatch.setattr(reference_data, 'engine', engine)
    reference_data.reference_table.cache_clear()
    try:
        with Session(engine) as db:
            assert [a.prj_id for a in reference_data.attributes(db, is_cde='Y')] == ['PRJ105']
            assert [a.prj_id for a in reference_data.attributes(db, is_cde='N')] == ['PRJ124']
    finally:
        reference_data.reference_table.cache_clear()
