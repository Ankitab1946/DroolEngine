"""Regression tests for template imports, CDE promotion and financial sources."""
from io import BytesIO
from pathlib import Path
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from fastapi.testclient import TestClient
from openpyxl import Workbook
from common.database import Base
from common import reference_data, database, execution, source_data
from common.import_rules import build_candidates, MAX_SIZE
from common.models import Rule, FinancialFact, Execution
from api import main


def template_bytes():
    wb=Workbook();sh=wb.active
    sh.append(['DQ - CDEs and Business rules','','','Banks','','','Insurance','',''])
    sh.append(['CDE','Business Control(Yes/No)','Proposed Business Rule','PRJ ID(non-_AR Ids)','PRJ ID(_AR Ids)','Attribute Name','PRJ ID(non-_AR Ids)','PRJ ID(_AR Ids)','Attribute Name'])
    sh.append(['Revenue','Y','Movement of >50%','PRJ105','PRJ124','Revenue','PRJ105','-','Revenue'])
    sh.append(['Ratio','Y','Not below 7%','PRJ105','-','Capital Ratio','','',''])
    b=BytesIO();wb.save(b);return b.getvalue()


def test_import_template_idempotent_and_approval(tmp_path,monkeypatch):
    eng=create_engine(f'sqlite:///{tmp_path / "rules.db"}',connect_args={'check_same_thread':False})
    with eng.begin() as c:
        c.execute(text('CREATE TABLE prj_attribute_master (prj_id TEXT PRIMARY KEY, attribute_name TEXT, is_cde BOOLEAN)'))
        c.execute(text('CREATE TABLE prj_portfolio_reference (short_code TEXT PRIMARY KEY, portfolio_name TEXT, is_active BOOLEAN)'))
        c.execute(text("INSERT INTO prj_attribute_master VALUES ('PRJ105','Revenue',0),('PRJ124','Revenue AR',1)"))
        c.execute(text("INSERT INTO prj_portfolio_reference VALUES ('BANK','Banks',1),('INS','Insurance',1)"))
        Base.metadata.create_all(c) # TEST fixture provisioning only
    sess=sessionmaker(eng,expire_on_commit=False)
    monkeypatch.setattr(reference_data,'engine',eng)
    monkeypatch.setattr(main,'SessionLocal',sess)
    monkeypatch.setenv('DQ_ALLOW_CDE_PROMOTION','true')
    reference_data.reference_table.cache_clear()
    try:
        blob=template_bytes()
        with sess() as db:
            preview=build_candidates(db,blob,'rules.xlsx')
            assert len(preview)==4
            assert len(set(x['rule_id'] for x in preview))==4
            assert any(x['needs_cde_update'] for x in preview)
            assert all(x['rule_type'] in ('MOVEMENT','LIMIT') for x in preview)
        client=TestClient(main.app)
        upload=lambda:client.post('/api/v1/dq/rules/import',files={'file':('rules.xlsx',blob,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')})
        r=upload();assert r.status_code==200,r.text
        batch_id=r.json()['batch_id']
        with eng.connect() as conn:
            assert conn.execute(text('SELECT is_cde FROM prj_attribute_master WHERE prj_id="PRJ105"')).scalar() == 0
        first=client.post(f'/api/v1/dq/rules/import/{batch_id}/confirm')
        assert first.status_code==200,first.text
        assert first.json()['created']>=1
        with eng.connect() as conn:
            assert conn.execute(text("SELECT is_cde FROM prj_attribute_master WHERE prj_id='PRJ105'")).scalar() == 0
        second=client.post(f'/api/v1/dq/rules/import/{batch_id}/confirm',params={'approve_cde_updates':'true'})
        assert second.status_code==200,second.text
        assert second.json()['created']>=1
        with eng.connect() as conn:
            assert conn.execute(text("SELECT is_cde FROM prj_attribute_master WHERE prj_id='PRJ105'")).scalar() == 1
            n=conn.execute(text('SELECT count(*) FROM dq_rules')).scalar()
        assert client.post(f'/api/v1/dq/rules/import/{batch_id}/confirm',params={'approve_cde_updates':'true'}).status_code==200
        with eng.connect() as conn: assert conn.execute(text('SELECT count(*) FROM dq_rules')).scalar()==n
        assert upload().json()['duplicates']==4
    finally: reference_data.reference_table.cache_clear()


def test_source_selector_and_cde_scoping(tmp_path,monkeypatch):
    eng=create_engine(f'sqlite:///{tmp_path / "source.db"}')
    with eng.begin() as c:
        c.execute(text('CREATE TABLE uns_financial_line_items (line_item_id INTEGER, filing_company TEXT, portfolio_code TEXT, prj_id TEXT, period TEXT, value TEXT, currency TEXT, unit TEXT, document_id TEXT)'))
        c.execute(text("INSERT INTO uns_financial_line_items VALUES (1,'Company A','BANK','PRJ105','2026-12','10','INR','PERCENT','DOC-X')"))
    sess=sessionmaker(eng)
    monkeypatch.setattr(source_data,'engine',eng)
    source_data.uns_table.cache_clear()
    try:
        with sess() as db:
            rows=source_data.load_rows(db,{'source':'UNS_FINANCIAL_LINE_ITEMS','period':'2026-12'})
            assert len(rows)==1 and rows[0].company=='Company A'
            assert rows[0].value==10
            assert source_data.load_rows(db,{'source':'UNS_FINANCIAL_LINE_ITEMS','period':'2025-12'})==[]
    finally:source_data.uns_table.cache_clear()


def test_openapi_exposes_import_confirmation_and_sources():
    paths=main.app.openapi()['paths']
    assert '/api/v1/dq/rules/import/{batch_id}/confirm' in paths
    assert '/api/v1/dq/sources' in paths
    assert 'source' in main.ExecutionInput.model_fields
