"""Regression: manually provisioned DQ tables may contain orphaned rules.

API reads and execution must not dereference a missing rule snapshot.
"""
from sqlalchemy import create_engine, text, select
from sqlalchemy.orm import sessionmaker
from fastapi.testclient import TestClient
from common.database import Base
from common.models import Rule, RuleMapping, RuleVersion, Execution, Result
from common.services import serialize_rule, version_for, change_rule_status, save_rule
from common.schemas import RuleInput
from common import reference_data
from api import main
import common.execution as engine_exec


def test_docs_offline_route_catalogue(monkeypatch):
    monkeypatch.setenv('DQ_API_KEY', 'secret')
    client = TestClient(main.app)
    docs = client.get('/docs')
    assert docs.status_code == 200
    assert 'Loading API routes' in docs.text
    assert "fetch('/openapi.json'" in docs.text
    assert 'swagger-ui-bundle.js' not in docs.text
    assert client.get('/swagger-cdn').status_code == 200
    schema=client.get('/openapi.json').json()
    assert len(schema['paths'])>=25
    assert '/api/v1/dq/rules/{rule_id}/audit' in schema['paths']


def test_orphan_rule_lists_and_edit_restores_history(tmp_path, monkeypatch):
    engine = create_engine(f'sqlite:///{tmp_path / "orphan.sqlite"}')
    with engine.begin() as conn:
        conn.execute(text('CREATE TABLE prj_attribute_master (prj_id TEXT PRIMARY KEY, is_cde BOOLEAN)'))
        conn.execute(text('CREATE TABLE prj_portfolio_reference (short_code TEXT PRIMARY KEY, portfolio_name TEXT, is_active BOOLEAN)'))
        conn.execute(text("INSERT INTO prj_attribute_master VALUES ('PRJ105', 1)"))
        conn.execute(text("INSERT INTO prj_portfolio_reference VALUES ('BANK','Banks',1)"))
        Base.metadata.create_all(conn)  # isolated test DB only
    sessions = sessionmaker(engine, expire_on_commit=False)
    monkeypatch.setattr(reference_data, 'engine', engine)
    monkeypatch.setattr(main, 'SessionLocal', sessions)
    monkeypatch.setattr(engine_exec, 'SessionLocal', sessions)
    reference_data.reference_table.cache_clear()
    try:
        with sessions() as db:
            db.add(Rule(id='ORPHAN',name='Broken seed rule',rule_type='LIMIT',status='ACTIVE',severity='HIGH',current_version=3))
            db.add(RuleMapping(rule_id='ORPHAN',prj_id='PRJ105',role='TARGET'))
            db.commit()
            orphan=db.get(Rule,'ORPHAN')
            assert version_for(db, orphan) is None
            data=serialize_rule(db, orphan)
            assert data['configuration_error']=='MISSING_RULE_VERSION'
            assert data['targets']==['PRJ105']
            try:
                change_rule_status(db,orphan,'INACTIVE')
                assert False, 'status change should reject missing rule history'
            except ValueError as e:
                assert 'no version' in str(e)
            db.rollback()
        client=TestClient(main.app)
        monkeypatch.delenv('DQ_API_KEY',raising=False)
        rules=client.get('/api/v1/dq/rules')
        assert rules.status_code==200
        assert rules.json()[0]['configuration_error']=='MISSING_RULE_VERSION'
        bad=client.post('/api/v1/dq/rules/ORPHAN/activate')
        assert bad.status_code==422
        with sessions() as db:
            fixed=save_rule(db,RuleInput(id='ORPHAN',name='Reconfigured',rule_type='LIMIT',status='ACTIVE',
                        targets=['PRJ105'],portfolios=['BANK'], config={'operator':'>=','threshold_value':'1.1','threshold_type':'PERCENTAGE'}),update=True)
            assert fixed.current_version==4
            assert db.scalar(select(RuleVersion).where(RuleVersion.rule_id=='ORPHAN',RuleVersion.version==4))
            assert serialize_rule(db,fixed)['targets']==['PRJ105']
    finally:
        reference_data.reference_table.cache_clear()


def test_execution_records_error_for_orphan_rule(tmp_path,monkeypatch):
    engine=create_engine(f'sqlite:///{tmp_path / "orphan_run.sqlite"}')
    with engine.begin() as conn:
        conn.execute(text('CREATE TABLE prj_attribute_master (prj_id TEXT PRIMARY KEY, is_cde BOOLEAN)'))
        conn.execute(text('CREATE TABLE prj_portfolio_reference (short_code TEXT PRIMARY KEY, portfolio_name TEXT, is_active BOOLEAN)'))
        Base.metadata.create_all(conn)
    sessions=sessionmaker(engine,expire_on_commit=False)
    monkeypatch.setattr(engine_exec,'SessionLocal',sessions)
    with sessions() as db:
        db.add(Rule(id='ORPHAN',name='Missing config',rule_type='LIMIT',status='ACTIVE',severity='HIGH',current_version=1))
        db.add(Execution(id='ORPHAN-RUN',scope={}))
        db.commit()
    engine_exec.execute('ORPHAN-RUN')
    with sessions() as db:
        assert db.get(Execution,'ORPHAN-RUN').status=='COMPLETED'
        results=db.scalars(select(Result).where(Result.execution_id=='ORPHAN-RUN')).all()
        assert len(results)==1
        assert results[0].outcome=='ERROR'
        assert 'MISSING_RULE_VERSION' in results[0].reason
