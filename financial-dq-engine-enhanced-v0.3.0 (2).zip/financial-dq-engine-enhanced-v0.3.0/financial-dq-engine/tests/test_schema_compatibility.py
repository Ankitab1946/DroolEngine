"""Regression tests: existing masters are read-only; startup does not issue DDL."""
import pytest
from sqlalchemy import create_engine, text, inspect, event
from common.database import Base, check_schema_compatibility
from common import models  # noqa: F401


def make_existing_reference_tables(conn):
    # TEST FIXTURES ONLY. Production reference masters are never created by app.
    conn.execute(text('CREATE TABLE prj_attribute_master (prj_id TEXT PRIMARY KEY, attribute_name TEXT, is_cde TEXT, cfi_id TEXT)'))
    conn.execute(text('CREATE TABLE prj_portfolio_reference (short_code TEXT PRIMARY KEY, portfolio_name TEXT, is_active TEXT, sector_name TEXT)'))


def test_old_schema_rejected_without_modification():
    engine = create_engine('sqlite://')
    with engine.begin() as connection:
        make_existing_reference_tables(connection)
        connection.execute(text('ALTER TABLE prj_attribute_master RENAME COLUMN is_cde TO legacy_cde'))
        connection.execute(text("INSERT INTO prj_attribute_master(prj_id, legacy_cde) VALUES ('KEEP_ME','Y')"))
        with pytest.raises(RuntimeError, match='Missing columns') as exc:
            check_schema_compatibility(connection)
        assert 'is_cde' in str(exc.value)
        assert connection.scalar(text('SELECT prj_id FROM prj_attribute_master')) == 'KEEP_ME'


def test_missing_tables_rejected_without_creating_them():
    engine = create_engine('sqlite://')
    statements = []
    @event.listens_for(engine, 'before_cursor_execute')
    def track(conn, cursor, statement, parameters, context, executemany):
        statements.append(statement)
    with engine.connect() as connection:
        with pytest.raises(RuntimeError, match='Missing tables'):
            check_schema_compatibility(connection)
        assert inspect(connection).get_table_names() == []
    assert not any('CREATE ' in s.upper() or 'DROP ' in s.upper() for s in statements)


def test_manually_created_schema_is_accepted():
    engine = create_engine('sqlite://')
    with engine.begin() as connection:
        Base.metadata.create_all(connection)  # simulate DBA provisioning in a test
        make_existing_reference_tables(connection)
        check_schema_compatibility(connection)
        assert 'prj_id' in {c['name'] for c in inspect(connection).get_columns('prj_attribute_master')}


def test_init_db_does_not_issue_ddl(monkeypatch):
    from common import database
    engine = create_engine('sqlite://')
    with engine.begin() as conn:
        Base.metadata.create_all(conn)
        make_existing_reference_tables(conn)
    emitted = []
    @event.listens_for(engine, 'before_cursor_execute')
    def track(conn, cursor, statement, parameters, context, executemany):
        emitted.append(statement.upper())
    monkeypatch.setattr(database, 'engine', engine)
    database.init_db()
    assert not any('CREATE ' in x or 'ALTER ' in x or 'DROP ' in x for x in emitted)


def test_legacy_pri_id_diagnostic_and_manual_rename():
    """Shows the exact mismatch, preserves existing records, and never self-migrates."""
    engine = create_engine('sqlite://')
    with engine.begin() as con:
        Base.metadata.create_all(con)  # TEST fixture only
        make_existing_reference_tables(con)
        con.execute(text("INSERT INTO prj_attribute_master(prj_id,is_cde) VALUES ('PRJ105','Y')"))
        con.execute(text("INSERT INTO dq_rules (id,name,rule_type,status,severity,current_version,created_at) VALUES ('R1','Rule','LIMIT','ACTIVE','HIGH',1,CURRENT_TIMESTAMP)"))
        con.execute(text("INSERT INTO dq_rule_executions (id,status,scope,requested_at) VALUES ('E1','QUEUED','{}',CURRENT_TIMESTAMP)"))
        con.execute(text("INSERT INTO demo_normalized_financial_facts (id,document_id,company,portfolio_code,prj_id,period,currency,unit,collection_type) VALUES (1,'DOC','Company','BANK','PRJ105','2026-12','INR','PERCENT','AR')"))
        con.execute(text("INSERT INTO dq_rule_cde_mapping (id,rule_id,prj_id,role,collection_type) VALUES (1,'R1','PRJ105','TARGET','ANY')"))
        con.execute(text("INSERT INTO dq_validation_results (id,execution_id,rule_id,rule_version,prj_id,outcome,reason,evidence,rule_snapshot,created_at) VALUES (1,'E1','R1',1,'PRJ105','PASS','ok','{}','{}',CURRENT_TIMESTAMP)"))
        for name in ('demo_normalized_financial_facts', 'dq_rule_cde_mapping', 'dq_validation_results'):
            con.execute(text(f'ALTER TABLE {name} RENAME COLUMN prj_id TO pri_id'))
        with pytest.raises(RuntimeError) as err:
            check_schema_compatibility(con)
        message = str(err.value)
        for name in ('demo_normalized_financial_facts', 'dq_rule_cde_mapping', 'dq_validation_results'):
            assert name in message
        assert 'prj_id' in message and 'pri_id' in message
        assert con.scalar(text('SELECT pri_id FROM dq_rule_cde_mapping WHERE id=1')) == 'PRJ105'
        # Simulates explicit DBA review and manually applied ALTER TABLE.
        for name in ('demo_normalized_financial_facts', 'dq_rule_cde_mapping', 'dq_validation_results'):
            con.execute(text(f'ALTER TABLE {name} RENAME COLUMN pri_id TO prj_id'))
        check_schema_compatibility(con)
        assert con.scalar(text('SELECT prj_id FROM dq_validation_results WHERE id=1')) == 'PRJ105'
