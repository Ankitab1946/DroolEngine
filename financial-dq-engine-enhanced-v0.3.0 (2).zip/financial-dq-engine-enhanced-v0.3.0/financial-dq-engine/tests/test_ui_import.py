"""Regression: Streamlit may launch with only ui/ on sys.path."""
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_streamlit_entry_can_import_common_from_ui_only(tmp_path):
    """Emulate Streamlit's script-path sys.path from outside the repo."""
    source = (ROOT / "ui" / "app.py").read_text(encoding="utf-8")
    preamble = source.split("import streamlit as st", 1)[0]
    # Streamlit's script context sets __file__, but does not guarantee repo
    # root on sys.path. Mimic this and check env config loads correctly.
    code = (
        "import os,sys; from pathlib import Path; "
        f"sys.path[:]=[{str(ROOT / 'ui')!r}]+[p for p in sys.path if p not in ('', {str(ROOT)!r})]; "
        f"__file__={str(ROOT / 'ui' / 'app.py')!r}; "
        "os.environ.setdefault('API_URL','http://localhost:8000'); os.environ.setdefault('DQ_API_KEY','test-local-key'); "
        + preamble
        + "\nassert str(PROJECT_ROOT) in sys.path; "
        "assert 'common.config' in sys.modules; "
        "assert os.getenv('API_URL'); assert os.getenv('DQ_API_KEY')\n"
    )
    env = dict(os.environ)
    env.pop("PYTHONPATH", None)
    env.setdefault("API_URL", "http://localhost:8000")
    env.setdefault("DQ_API_KEY", "test-local-key")
    result = subprocess.run([sys.executable, "-c", code], cwd=tmp_path,
                            env=env, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr


def test_ui_import_does_not_override_supplied_credentials(tmp_path):
    source = (ROOT / "ui" / "app.py").read_text(encoding="utf-8")
    preamble = source.split("import streamlit as st", 1)[0]
    code = (
        f"__file__={str(ROOT / 'ui' / 'app.py')!r}\n"
        + preamble
        + "\nassert os.environ['API_URL']=='http://custom-api:9000'\n"
        + "assert os.environ['DQ_API_KEY']=='injected-test-key'\n"
    )
    env = dict(os.environ, API_URL="http://custom-api:9000", DQ_API_KEY="injected-test-key")
    result = subprocess.run([sys.executable, "-c", code], cwd=tmp_path,
                            env=env, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
