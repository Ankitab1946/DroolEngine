# Solution design and integration boundaries

## Independent applications

| Package/service | Responsibility | Interface |
|---|---|---|
| `api/` | Rule/attribute/portfolio management, orchestration endpoints, reports | FastAPI REST |
| `ui/` | Business rule builder, rule catalog, monitoring dashboard | HTTP calls to API |
| `common/` | Rule schema, validation engine, DB models, reporting, shared business logic | Shared Python package imported by services |
| `worker/` | Asynchronous validations, recurring schedule dispatcher | Celery queue + SQLAlchemy |
| PostgreSQL | DQ metadata, execution history, result persistence | SQLAlchemy |
| Redis | Celery broker and task result backend | Celery protocol |

## Demo DQ relational model

```mermaid
erDiagram
  dq_rules ||--o{ dq_rule_versions : versions
  dq_rules ||--o{ dq_rule_cde_mapping : maps
  dq_rule_executions ||--o{ dq_validation_results : contains
  prj_attribute_master ||--o{ demo_normalized_financial_facts : identifies
  prj_portfolio_reference ||--o{ demo_normalized_financial_facts : scopes
```

- A `dq_rule_versions` record snapshots the target list, portfolio list and JSON threshold definition. Older versions are never overwritten.
- `dq_validation_results` embeds the version/config/CDE status used at runtime so that changing the master classification does not rewrite history.
- One rule may map to many PRJ IDs; the same PRJ ID may belong to many rules. Operands for cross-CDE comparisons use `role=OPERAND`.
- A disabled CDE is skipped at execution even if the rule remains active.
- Execution status (`COMPLETED`) is distinct from validation result (`FAIL`).

## Extension plan (production)

1. Inspect real schemas, document lineage keys and AR/non-AR/CFI crosswalks. Create approved read-only SQL views with stable logical facts, rather than guessing columns of `prj_financials_v2`.
2. Connect a source adapter returning a typed row set or SQLAlchemy selectable. Separate source DB access credentials from DQ metadata write credentials.
3. Replace demo representations with mapped views; do not call `create_all()` on production tables. Apply reviewed Alembic migrations in a dedicated DQ schema.
4. Push mandatory, duplicate, limit, and reconciliation operations into parameterized SQL for scale. Use an immutable snapshot ID for each execution.
5. Add optional Great Expectations runner: compile compatible rule versions into an expectation suite, execute GX on an authorized SQL batch, then normalize GX validation outputs into `dq_validation_results` under the same execution ID. Keep custom SQL/Python handlers for complex movement/reconciliation.
6. Implement full SSO/OIDC and RBAC, dual-control approvals, scheduled mailer, safe SQL expression DSL, supervised Celery workers, job cancellation, retry/idempotency, and monitoring.
7. Expand Excel import to handle real unstructured workbook headings and repeat column labels, optionally generating AI-assisted **drafts** that always require approval.

## Known semantics to confirm with business

- `ABOVE 100%`, `BELOW 110%`, `NOT BELOW 7%`: these may describe expected PASS conditions or FAIL triggers. In MVP, `LIMIT` is a PASS condition.
- `Movement > 50%`: in MVP this is a FAIL trigger when the magnitude of signed movement is above 50%; `direction` changes the movement metric.
- `PREVIOUS_PERIOD` defaults to previous calendar year. Validate reporting calendars (monthly, quarterly, annual) and restatements before production use.
- Rules with no matching rows return `NOT_APPLICABLE` rather than falsely reporting PASS.
- A rule requiring multiple operands is skipped if a required operand is not a current CDE.

## Production security warnings

Local Compose credentials are public sample values. Use secrets instead; enforce strict API roles, row/portfolio entitlements, rate limiting, query timeouts, audit logging, TLS, read-only source credentials, and approved SMTP/Graph account. Free-form SQL rule execution is intentionally absent.

## Poetry and PostgreSQL configuration (v0.1.1)

- Single root `pyproject.toml` manages the four separate services/packages; `common/` remains shared code, not a new microservice.
- `common/config.py` is the common environment adapter, loading `.env` without overriding OS/container variables.
- `common/database.py` exposes the same `engine`, `SessionLocal`, `init_db` and `session_scope` API as before. It selects SQLite when `ENABLE_POSTGRES=false`; otherwise psycopg connects through `PG_HOST`, `PG_PORT`, `PG_DATABASE`, `POSTGRES_USER`, `POSTGRES_PASSWORD` and `POSTGRES_SSLMODE`.
- `PG_SCHEMA` selects the dedicated DQ schema using connection `search_path`. The source registry now reflects existing `prj_attribute_master` and `prj_portfolio_reference`; normalized facts still use the standalone demo table until the actual `prj_financials_v2` schema is mapped.
- The web API and Celery worker each import the shared connection factory, so database settings cannot drift between services in the same environment.
- All Compose application commands now use `poetry run`; the `postgres` container continues to be the local PostgreSQL service.
- No business-rule functions, endpoints, UI screen workflows, data models, or result-reporting contracts were changed by the conversion.


## Database provisioning

PostgreSQL schema and tables are DBA-managed. Run `sql/postgres_create_tables.sql` manually in the existing `PG_SCHEMA` before startup. API and workers only verify mapped tables/columns: they never create a schema or tables. This preserves existing DB permissions and data.

## Existing PRJ reference master integration (current)

`common/reference_data.py` reflects `prj_attribute_master` and
`prj_portfolio_reference` using the configured PostgreSQL search path. The
application requires no DDL privileges at runtime and never seeds or changes
the existing PRJ masters. Rule activation validates current CDE status; rule
execution rechecks it and saves the classification in result snapshots.

The manual SQL script now provisions only the nine DQ-owned/demo-fact tables.
With `SEED_DEMO=true`, the startup routine seeds a handful of DQ-owned
records using actual PRJ master IDs (only in a test database). No raw or
normalized production financial tables are altered.

### Existing DQ table column drift

Startup is strictly read-only: it diagnoses absent model columns and lists actual columns. DBA-owned manual inspection and reviewed SQL are provided in `sql/postgres_inspect_prj_id.sql` and `sql/postgres_repair_prj_id.sql`. No SQL migration is executed at runtime; `CREATE TABLE IF NOT EXISTS` does not reconcile existing table layouts.
