from sqlalchemy import select
from datetime import datetime, timezone
from common.models import Rule, RuleVersion, RuleMapping
from common.schemas import RuleInput
from common.reference_data import get_attribute, get_portfolio

def version_for(db, rule):
    return db.scalar(select(RuleVersion).where(RuleVersion.rule_id==rule.id, RuleVersion.version==rule.current_version))

def validate_references(db, data: RuleInput):
    ids = set(data.targets)
    if data.config.get('other_prj_id'): ids.add(data.config['other_prj_id'])
    missing = {prj for prj in ids if get_attribute(db, prj) is None}
    if missing: raise ValueError(f'Unknown PRJ IDs: {sorted(missing)}')
    missing_ports = {code for code in data.portfolios if get_portfolio(db, code) is None}
    if missing_ports: raise ValueError(f'Unknown portfolios: {sorted(missing_ports)}')
    if data.status == 'ACTIVE' and data.config.get('require_cde', True):
        inactive = [prj for prj in ids if get_attribute(db, prj).is_cde != 'Y']
        if inactive: raise ValueError(f'Cannot activate rule: non-CDE attributes {inactive}')

def record_version(db, rule, *, config, targets, portfolios, changed_by, change_reason):
    """SCD2 transition: close prior version and insert a new immutable snapshot."""
    current = version_for(db, rule) if rule.current_version else None
    timestamp = datetime.now(timezone.utc)
    if current:
        current.effective_to = timestamp
        current.is_current = False
        rule.current_version += 1
    else:
        rule.current_version = 1
    value = config.get('threshold_value', config.get('threshold'))
    v = RuleVersion(rule_id=rule.id, version=rule.current_version, config=config,
        targets=list(targets), portfolios=list(portfolios), effective_from=timestamp,
        effective_to=None, is_current=True, status_snapshot=rule.status,
        name_snapshot=rule.name, severity_snapshot=rule.severity,
        rule_type_snapshot=rule.rule_type, threshold_value=value,
        threshold_type=config.get('threshold_type'), changed_by=changed_by,
        change_reason=change_reason)
    db.add(v)
    return v


def change_rule_status(db, rule, status, *, changed_by='api', change_reason=None):
    if rule.status == status:
        return rule  # No change => no spurious history row
    old = version_for(db, rule)
    rule.status = status
    record_version(db, rule, config=dict(old.config), targets=old.targets,
        portfolios=old.portfolios, changed_by=changed_by,
        change_reason=change_reason or f'Status changed to {status}')
    db.commit()
    return rule


def save_rule(db, data: RuleInput, update=False):
    validate_references(db, data)
    rule = db.get(Rule, data.id)
    if update and not rule: raise LookupError('Rule not found')
    if not update and rule: raise ValueError('Rule already exists')
    if rule:
        rule.name, rule.rule_type, rule.severity, rule.status = data.name, data.rule_type, data.severity, data.status
        db.query(RuleMapping).filter(RuleMapping.rule_id==rule.id).delete(synchronize_session=False)
    else:
        rule = Rule(id=data.id, name=data.name, rule_type=data.rule_type,
                    status=data.status, severity=data.severity, current_version=0)
        db.add(rule)
        db.flush()
    cfg = {**data.config, 'require_cde': data.config.get('require_cde', True)}
    record_version(db, rule, config=cfg, targets=data.targets, portfolios=data.portfolios,
        changed_by=data.changed_by, change_reason=data.change_reason if update else 'Rule created')
    for target in sorted(set(data.targets)):
        db.add(RuleMapping(rule_id=data.id, prj_id=target, role='TARGET'))
    if data.config.get('other_prj_id'):
        db.add(RuleMapping(rule_id=data.id, prj_id=data.config['other_prj_id'], role='OPERAND'))
    db.commit()
    return rule


def serialize_history(v):
    return {'version': v.version, 'status': v.status_snapshot, 'rule_name': v.name_snapshot,
        'rule_type': v.rule_type_snapshot, 'severity': v.severity_snapshot,
        'threshold_value': str(v.threshold_value) if v.threshold_value is not None else None,
        'threshold_type': v.threshold_type, 'config': v.config, 'targets': v.targets,
        'portfolios': v.portfolios, 'effective_from': v.effective_from.isoformat() if v.effective_from else None,
        'effective_to': v.effective_to.isoformat() if v.effective_to else None,
        'is_current': v.is_current, 'changed_by': v.changed_by, 'change_reason': v.change_reason}

def serialize_rule(db, rule):
    v=version_for(db,rule)
    return {'id':rule.id,'name':rule.name,'rule_type':rule.rule_type,'status':rule.status,'severity':rule.severity,'version':rule.current_version,'targets':v.targets,'portfolios':v.portfolios,'config':v.config, 'threshold_value':str(v.threshold_value) if v.threshold_value is not None else None, 'threshold_type':v.threshold_type}
