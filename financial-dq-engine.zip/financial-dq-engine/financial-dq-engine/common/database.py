"""Shared SQLAlchemy session factory. PostgreSQL connection uses the exact PG_* env names."""
from sqlalchemy import create_engine, text
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from common.config import database_connection, postgres_enabled, postgres_schema

DATABASE_URL, connect_args = database_connection()
engine = create_engine(DATABASE_URL, pool_pre_ping=True, connect_args=connect_args)
SessionLocal = sessionmaker(engine, expire_on_commit=False)

class Base(DeclarativeBase):
    pass

def init_db():
    from common import models  # noqa: F401
    if postgres_enabled():
        # The supplied schema is an isolated DQ schema. Do not create objects in public.
        schema = postgres_schema()
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{schema}"'))
    Base.metadata.create_all(engine)

def session_scope():
    return SessionLocal()
