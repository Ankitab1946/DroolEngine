from decimal import Decimal
from sqlalchemy import select
from common.database import SessionLocal,init_db
from common.models import Attribute,Portfolio,FinancialFact,Rule
from common.schemas import RuleInput
from common.services import save_rule

def seed():
    init_db()
    with SessionLocal() as db:
        if db.scalar(select(Attribute.prj_id).limit(1)): return
        db.add_all([Attribute(prj_id=i,name=n,is_cde='Y') for i,n in [('PRJ105','Capital adequacy ratio'),('PRJ124','Revenue'),('PRJ2318','Total Assets'),('PRJ2362','Total Liabilities')]])
        db.add(Attribute(prj_id='PRJ999',name='Internal remarks',is_cde='N'))
        db.add_all([Portfolio(short_code='BANK',portfolio_name='Banks',sector_name='Financial Services'),Portfolio(short_code='INS',portfolio_name='Insurance',sector_name='Financial Services')])
        data=[('PRJ105','2025-12','8.4','PERCENT'),('PRJ105','2026-12','5.8','PERCENT'),('PRJ124','2025-12','100','MILLION'),('PRJ124','2026-12','170','MILLION'),('PRJ2318','2026-12','500','MILLION'),('PRJ2362','2026-12','380','MILLION')]
        db.add_all([FinancialFact(document_id='DEMO-001',company='Demo Bank Ltd',portfolio_code='BANK',prj_id=p,period=period,value=Decimal(v),unit=unit,currency='INR') for p,period,v,unit in data]);db.commit()
        save_rule(db,RuleInput(id='Rule_06',name='Capital ratio not below 7%',rule_type='LIMIT',targets=['PRJ105'],portfolios=['BANK'],status='ACTIVE',config={'operator':'>=','threshold':'7','require_cde':True},severity='HIGH'))
        save_rule(db,RuleInput(id='Rule_09',name='Revenue movement above 50% flag',rule_type='MOVEMENT',targets=['PRJ124'],portfolios=['BANK'],status='ACTIVE',config={'operator':'>','threshold':'50','comparison_period':'PREVIOUS_YEAR','direction':'BOTH'},severity='HIGH'))
if __name__=='__main__': seed()
