from datetime import datetime, timezone
from sqlalchemy import String, Integer, ForeignKey, DateTime, Numeric, Boolean, Text, JSON, UniqueConstraint, Index
from sqlalchemy.orm import Mapped, mapped_column
from common.database import Base

def now(): return datetime.now(timezone.utc)

# Isolated demo representations: production source tables are never created or altered.
class Attribute(Base):
    __tablename__ = 'demo_cfv_attribute_masters'
    prj_id: Mapped[str] = mapped_column(String(80), primary_key=True)
    name: Mapped[str] = mapped_column(String(255))
    is_cde: Mapped[str] = mapped_column(String(1), default='Y')
    cfi_id: Mapped[str | None] = mapped_column(String(80), nullable=True)

class Portfolio(Base):
    __tablename__ = 'demo_portfolio_refrence'
    short_code: Mapped[str] = mapped_column(String(50), primary_key=True)
    portfolio_name: Mapped[str] = mapped_column(String(100))
    sector_name: Mapped[str | None] = mapped_column(String(100))
    sub_sector: Mapped[str | None] = mapped_column(String(100))
    document_type_id: Mapped[str | None] = mapped_column(String(80))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

class FinancialFact(Base):
    __tablename__ = 'demo_normalized_financial_facts'
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    document_id: Mapped[str] = mapped_column(String(80))
    company: Mapped[str] = mapped_column(String(160))
    portfolio_code: Mapped[str] = mapped_column(String(50))
    prj_id: Mapped[str] = mapped_column(String(80))
    period: Mapped[str] = mapped_column(String(10))  # YYYY-MM or YYYY-MM-DD
    value: Mapped[object | None] = mapped_column(Numeric(25, 8), nullable=True)
    currency: Mapped[str] = mapped_column(String(10), default='INR')
    unit: Mapped[str] = mapped_column(String(30), default='PERCENT')
    collection_type: Mapped[str] = mapped_column(String(20), default='NON_AR')
    __table_args__ = (Index('ix_demo_fact_scope', 'portfolio_code', 'company', 'prj_id', 'period'),)

class Rule(Base):
    __tablename__ = 'dq_rules'
    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    rule_type: Mapped[str] = mapped_column(String(50))
    status: Mapped[str] = mapped_column(String(20), default='DRAFT')
    severity: Mapped[str] = mapped_column(String(20), default='MEDIUM')
    current_version: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class RuleVersion(Base):
    __tablename__ = 'dq_rule_versions'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    rule_id: Mapped[str] = mapped_column(ForeignKey('dq_rules.id'))
    version: Mapped[int] = mapped_column(Integer)
    config: Mapped[dict] = mapped_column(JSON)
    targets: Mapped[list] = mapped_column(JSON)
    portfolios: Mapped[list] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    __table_args__ = (UniqueConstraint('rule_id', 'version'),)

class RuleMapping(Base):
    __tablename__ = 'dq_rule_cde_mapping'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    rule_id: Mapped[str] = mapped_column(ForeignKey('dq_rules.id'))
    prj_id: Mapped[str] = mapped_column(String(80))
    role: Mapped[str] = mapped_column(String(30), default='TARGET')
    collection_type: Mapped[str] = mapped_column(String(20), default='ANY')
    __table_args__ = (UniqueConstraint('rule_id', 'prj_id', 'role', 'collection_type'),)

class Execution(Base):
    __tablename__ = 'dq_rule_executions'
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    status: Mapped[str] = mapped_column(String(20), default='QUEUED')
    scope: Mapped[dict] = mapped_column(JSON)
    requested_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    error: Mapped[str | None] = mapped_column(Text)
    idempotency_key: Mapped[str | None] = mapped_column(String(120), unique=True)

class Result(Base):
    __tablename__ = 'dq_validation_results'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    execution_id: Mapped[str] = mapped_column(ForeignKey('dq_rule_executions.id'))
    rule_id: Mapped[str] = mapped_column(String(80))
    rule_version: Mapped[int] = mapped_column(Integer)
    prj_id: Mapped[str] = mapped_column(String(80))
    outcome: Mapped[str] = mapped_column(String(25))
    reason: Mapped[str] = mapped_column(Text)
    company: Mapped[str | None] = mapped_column(String(160))
    portfolio_code: Mapped[str | None] = mapped_column(String(50))
    period: Mapped[str | None] = mapped_column(String(10))
    document_id: Mapped[str | None] = mapped_column(String(80))
    actual: Mapped[str | None] = mapped_column(String(100))
    expected: Mapped[str | None] = mapped_column(String(100))
    evidence: Mapped[dict] = mapped_column(JSON, default=dict)
    rule_snapshot: Mapped[dict] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    __table_args__ = (Index('ix_dq_result_exec', 'execution_id'),)

class Schedule(Base):
    __tablename__ = 'dq_rule_schedules'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    frequency: Mapped[str] = mapped_column(String(20))
    hour_utc: Mapped[int] = mapped_column(Integer, default=0)
    minute_utc: Mapped[int] = mapped_column(Integer, default=0)
    day_of_month: Mapped[int] = mapped_column(Integer, default=1)
    rule_ids: Mapped[list] = mapped_column(JSON, default=list)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    last_fire_key: Mapped[str | None] = mapped_column(String(30))

class ImportBatch(Base):
    __tablename__ = 'dq_rule_import_batches'
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    filename: Mapped[str] = mapped_column(String(255))
    candidates: Mapped[list] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Notification(Base):
    __tablename__ = 'dq_notification_history'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    execution_id: Mapped[str] = mapped_column(String(36))
    recipient: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(30))
    reason: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
