"""Shared domain, persistence, validation and reporting services."""
