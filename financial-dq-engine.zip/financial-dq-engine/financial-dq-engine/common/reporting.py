from io import BytesIO
from collections import Counter
from sqlalchemy import select
from openpyxl import Workbook
from common.models import Result

def get_results(db, execution_id):
    rows=db.scalars(select(Result).where(Result.execution_id==execution_id).order_by(Result.id)).all()
    return [{'rule_id':r.rule_id,'version':r.rule_version,'prj_id':r.prj_id,'outcome':r.outcome,'reason':r.reason,'company':r.company,'portfolio':r.portfolio_code,'period':r.period,'document_id':r.document_id,'actual':r.actual,'expected':r.expected,'evidence':r.evidence,'rule_snapshot':r.rule_snapshot} for r in rows]

def summary(db, execution_id):
    rows=get_results(db,execution_id)
    return {'execution_id':execution_id,'total':len(rows),'outcomes':dict(Counter(r['outcome'] for r in rows)),'results':rows}

def excel_report(db, execution_id):
    data=summary(db,execution_id);wb=Workbook();overview=wb.active;overview.title='Overview';overview.append(['DQ Execution',execution_id]);overview.append(['Total outcomes',data['total']]);
    for key,value in data['outcomes'].items(): overview.append([key,value])
    sheet=wb.create_sheet('Validation Results');cols=['rule_id','version','prj_id','outcome','reason','company','portfolio','period','document_id','actual','expected'];sheet.append(cols)
    for row in data['results']:sheet.append([row.get(c) for c in cols])
    sheet.freeze_panes='A2';sheet.auto_filter.ref=sheet.dimensions
    bio=BytesIO();wb.save(bio);return bio.getvalue()
