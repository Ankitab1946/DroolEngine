import os
from datetime import datetime, timezone
from celery import Celery
from sqlalchemy import select
from common.database import SessionLocal,init_db
from common.models import Schedule, Execution
from common.execution import execute
from uuid import uuid4

celery_app=Celery('dq',broker=os.getenv('REDIS_URL','redis://localhost:6379/0'),backend=os.getenv('REDIS_URL','redis://localhost:6379/0'))
celery_app.conf.beat_schedule={'dispatch-due-schedules':{'task':'worker.tasks.dispatch_schedules','schedule':60.0}}
celery_app.conf.timezone='UTC'

@celery_app.task(name='worker.tasks.run_validation')
def run_validation(execution_id):
    init_db();execute(execution_id)

@celery_app.task(name='worker.tasks.dispatch_schedules')
def dispatch_schedules():
    init_db();now=datetime.now(timezone.utc)
    with SessionLocal() as db:
        for schedule in db.scalars(select(Schedule).where(Schedule.active==True)).all():
            if (now.hour,now.minute)<(schedule.hour_utc,schedule.minute_utc):continue
            if schedule.frequency=='MONTHLY' and now.day!=schedule.day_of_month:continue
            key=now.strftime('%Y-%m-%d')
            if schedule.last_fire_key==key:continue
            eid=str(uuid4());db.add(Execution(id=eid,scope={'rule_ids':schedule.rule_ids,'trigger':'SCHEDULE','schedule_id':schedule.id}));schedule.last_fire_key=key
            db.commit();run_validation.delay(eid)
