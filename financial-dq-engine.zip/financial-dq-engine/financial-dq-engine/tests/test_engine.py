from decimal import Decimal
from types import SimpleNamespace
from common.execution import passes,evaluate,period_predecessor

def test_limit():
    assert passes(Decimal('7'),'>=',7)
    assert not passes(Decimal('5.8'),'>=',7)

def test_month_predecessor():
    assert period_predecessor('2026-12','PREVIOUS_YEAR')=='2025-12'
    assert period_predecessor('2026-01','PREVIOUS_MONTH')=='2025-12'

def test_movement_breach():
    old=SimpleNamespace(company='A',portfolio_code='BANK',prj_id='PRJ124',period='2025-12',collection_type='NON_AR',currency='INR',unit='MILLION',value=Decimal(100))
    new=SimpleNamespace(company='A',portfolio_code='BANK',prj_id='PRJ124',period='2026-12',collection_type='NON_AR',currency='INR',unit='MILLION',value=Decimal(170))
    key=('A','BANK','PRJ124','2025-12','NON_AR')
    result=evaluate('MOVEMENT',[old,new],new,{'operator':'>','threshold':'50','comparison_period':'PREVIOUS_YEAR','direction':'BOTH'},{key:[old]})
    assert result[0] is False
    assert result[3]['movement_percent']=='70.0'

def test_missing_baseline_skipped():
    new=SimpleNamespace(company='A',portfolio_code='BANK',prj_id='X',period='2026-12',collection_type='NON_AR',currency='INR',unit='MILLION',value=Decimal(170))
    assert evaluate('MOVEMENT',[new],new,{'operator':'>','threshold':'50'}, {})[0] is None
