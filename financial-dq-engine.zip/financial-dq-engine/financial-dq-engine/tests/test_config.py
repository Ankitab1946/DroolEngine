import pytest
from common.config import database_connection, postgres_schema


def test_sqlite_when_postgres_disabled(monkeypatch):
    monkeypatch.setenv('ENABLE_POSTGRES', 'false')
    monkeypatch.setenv('PG_HOST', 'ignored')
    url, args = database_connection()
    assert url.startswith('sqlite:///')
    assert args['check_same_thread'] is False


def test_postgres_uses_all_requested_environment_fields(monkeypatch):
    for k,v in {
        'ENABLE_POSTGRES':'true', 'PG_HOST':'db.example.test', 'PG_PORT':'5544',
        'PG_DATABASE':'financial_dq', 'PG_SCHEMA':'dq_checks',
        'POSTGRES_USER':'operator', 'POSTGRES_PASSWORD':'secret@with:chars',
        'POSTGRES_SSLMODE':'require'
    }.items():
        monkeypatch.setenv(k, v)
    url,args=database_connection()
    assert 'operator:secret%40with%3Achars@db.example.test:5544/financial_dq' in url
    assert args['sslmode']=='require'
    assert args['options']=='-csearch_path=dq_checks,public'


def test_rejects_unsafe_pg_schema(monkeypatch):
    monkeypatch.setenv('PG_SCHEMA','public')
    with pytest.raises(ValueError):postgres_schema()
    monkeypatch.setenv('PG_SCHEMA','dq;DROP SCHEMA public')
    with pytest.raises(ValueError):postgres_schema()


def test_invalid_postgres_sslmode(monkeypatch):
    monkeypatch.setenv('ENABLE_POSTGRES','true')
    monkeypatch.setenv('POSTGRES_SSLMODE','unsafe')
    with pytest.raises(ValueError):database_connection()
